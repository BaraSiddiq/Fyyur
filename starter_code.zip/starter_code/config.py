import os
SECRET_KEY = os.urandom(32)
# Grabs the folder where the script runs.
basedir = os.path.abspath(os.path.dirname(__file__))

# Enable debug mode.
DEBUG = True

# Connect to the database

dialict = 'postgresql'
admin = 'postgres'
#write your password here
password = ''
host = 'localhost'
port = '5432'
db = 'Test1'

db_path = f'{dialict}://{admin}:{password}@{host}:{port}/{db}'
db_pathNopassword = f'{dialict}://{admin}@{host}:{port}/{db}'
# TODO:***IMPLEMENT DATABASE URL
SQLALCHEMY_DATABASE_URI = db_path
